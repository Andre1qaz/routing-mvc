<h1>Tentang Saya</h1> 
<p>Nama saya Andre . Saya sedang belajar Routing di laravel!</p> 
<a href="/profil">Kembali ke Profil</a> 
