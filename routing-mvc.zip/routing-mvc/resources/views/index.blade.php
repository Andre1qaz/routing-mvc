<!DOCTYPE html> 
<html> 
<head> 
    <title>Profil Saya</title> 
</head> 
<body> 
    <h1>Halaman Profil Utama</h1> 
    <p>Selamat datang di halaman profil Laravel!</p> 
    <a href="/profil/about">Tentang Saya</a> | 
    <a href="/profil/contact">Kontak</a> 
</body> 
</html> 
